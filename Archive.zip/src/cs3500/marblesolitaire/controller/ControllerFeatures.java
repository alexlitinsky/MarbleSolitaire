package cs3500.marblesolitaire.controller;

/**
 * Represents controller features.
 */
public interface ControllerFeatures {

  /**
   * Gets a row and a col.
   */
  void takeRowCol();
}
