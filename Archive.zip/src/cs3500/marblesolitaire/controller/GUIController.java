package cs3500.marblesolitaire.controller;

/**
 * Represents a GUI controller.
 */
public class GUIController implements ControllerFeatures {
  @Override
  public void takeRowCol() {
    // takes in a row
  }
}
