package cs3500.marblesolitaire;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.view.SwingGuiView;

/**
 * Represents a GUI for Marble Solitaire.
 */
public class MarbleSolitaireGUI {
  /**
   * The main method of the gui.
   * @param args the args of the main method
   */
  public static void main(String[] args) {

    SwingGuiView view = new SwingGuiView(new EnglishSolitaireModel());

  }
}
